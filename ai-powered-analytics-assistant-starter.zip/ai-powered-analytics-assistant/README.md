# AI-Powered Analytics Assistant (Starter Project)

A portfolio project exploring how natural-language interfaces can make business data easier to analyze. This starter app lets a user upload a CSV, inspect the dataset, ask basic questions about the data, and generate simple summaries using Python and Pandas.

> **Project status:** Starter implementation. This repository does not yet contain a production MCP server or a live LLM integration. Add those only after implementing and testing them.

## Features

- Upload a CSV file
- Preview rows and inspect column names and data types
- View basic dataset statistics
- Ask simple questions about row count, columns, missing values, and numeric summaries
- Optional LLM integration can be added later
- Clear separation between data handling and the Streamlit interface

## Tech stack

- Python
- Streamlit
- Pandas
- Git and GitHub

## Run locally

1. Install Python 3.10 or later.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Create and activate a virtual environment:

   ```bash
   python -m venv .venv
   # Windows:
   .venv\\Scripts\\activate
   # macOS/Linux:
   source .venv/bin/activate
   ```

5. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

6. Start the app:

   ```bash
   streamlit run app.py
   ```

7. Upload a CSV and try questions such as:
   - How many rows are in this dataset?
   - Which columns have missing values?
   - Show summary statistics.
   - What columns are available?

## Project structure

```text
ai-powered-analytics-assistant/
├── app.py
├── analytics.py
├── requirements.txt
├── .gitignore
├── .env.example
└── README.md
```

## Roadmap

- [ ] Add an LLM provider through environment-based API configuration
- [ ] Add safe, validated natural-language-to-analysis workflows
- [ ] Implement an MCP server with explicitly scoped tools
- [ ] Add tests for data handling and query behavior
- [ ] Add sample data that contains no personal or confidential information
- [ ] Deploy a demo and add screenshots

## Security and limitations

- Do not upload confidential, personal, or employer-owned data.
- Never commit API keys, access tokens, passwords, or `.env` files.
- Treat uploaded CSV files as untrusted input.
- This starter app answers only a small set of predefined data questions; it does not execute arbitrary Python or SQL from user prompts.
- Do not describe the MCP or LLM features as implemented until they are built and tested.

## Portfolio description

**AI-Powered Analytics Assistant — Python, Pandas, Streamlit**

Built a starter application for exploring business data through a simple interface. Users can upload CSV files, inspect data quality, view descriptive statistics, and ask predefined questions about dataset structure. The project is designed as a foundation for future LLM and MCP integration.

Update this description to reflect only features you have personally implemented, tested, and can explain in an interview.
