from __future__ import annotations

import pandas as pd
import streamlit as st

from analytics import answer_question, dataset_overview

st.set_page_config(
    page_title="AI-Powered Analytics Assistant",
    page_icon="📊",
    layout="wide",
)

st.title("📊 AI-Powered Analytics Assistant")
st.caption(
    "A starter data-analysis app built with Python, Pandas, and Streamlit. "
    "LLM/MCP integrations are planned, not included in this version."
)

with st.sidebar:
    st.header("Upload data")
    uploaded = st.file_uploader("Choose a CSV file", type=["csv"])
    st.info("Use sample or non-confidential data. Do not upload sensitive information.")

if not uploaded:
    st.markdown(
        """
        ### Get started
        Upload a CSV file in the sidebar to:
        - Preview the data
        - Review missing values and duplicate rows
        - Inspect column types and summary statistics
        - Ask predefined questions about the dataset
        """
    )
    st.stop()

try:
    df = pd.read_csv(uploaded)
except Exception as exc:
    st.error(f"Could not read this CSV file: {exc}")
    st.stop()

if df.empty:
    st.warning("The uploaded CSV contains no data rows.")
    st.stop()

overview = dataset_overview(df)
c1, c2, c3, c4 = st.columns(4)
c1.metric("Rows", f"{overview['rows']:,}")
c2.metric("Columns", f"{overview['columns']:,}")
c3.metric("Missing cells", f"{int(df.isna().sum().sum()):,}")
c4.metric("Duplicate rows", f"{overview['duplicate_rows']:,}")

tab_preview, tab_quality, tab_stats, tab_ask = st.tabs(
    ["Data preview", "Data quality", "Statistics", "Ask about data"]
)

with tab_preview:
    st.subheader("Preview")
    st.dataframe(df.head(100), use_container_width=True)
    st.subheader("Column types")
    types = pd.DataFrame({
        "Column": df.columns.astype(str),
        "Data type": [str(dtype) for dtype in df.dtypes],
    })
    st.dataframe(types, use_container_width=True, hide_index=True)

with tab_quality:
    st.subheader("Missing values")
    missing = df.isna().sum().rename("Missing values").to_frame()
    missing["Missing %"] = (missing["Missing values"] / max(len(df), 1) * 100).round(2)
    st.dataframe(missing, use_container_width=True)
    st.write(f"Duplicate rows: **{overview['duplicate_rows']:,}**")

with tab_stats:
    st.subheader("Descriptive statistics")
    numeric = df.select_dtypes(include="number")
    if numeric.empty:
        st.info("No numeric columns found.")
    else:
        st.dataframe(numeric.describe().T.round(2), use_container_width=True)

with tab_ask:
    st.subheader("Ask a predefined question")
    st.caption(
        "This starter version does not send data to an LLM. It responds to a limited "
        "set of predefined questions."
    )
    question = st.text_input(
        "Your question",
        placeholder="e.g. Which columns have missing values?",
    )
    if st.button("Analyze", type="primary"):
        st.write(answer_question(df, question))
