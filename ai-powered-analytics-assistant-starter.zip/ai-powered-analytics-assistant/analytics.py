"""Safe, predefined analytics helpers for uploaded tabular data."""

from __future__ import annotations

import pandas as pd


def dataset_overview(df: pd.DataFrame) -> dict:
    """Return basic, non-sensitive structural information about a dataframe."""
    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "column_names": [str(c) for c in df.columns],
        "missing_by_column": {
            str(k): int(v) for k, v in df.isna().sum().items() if int(v) > 0
        },
        "duplicate_rows": int(df.duplicated().sum()) if len(df.columns) else 0,
    }


def answer_question(df: pd.DataFrame, question: str) -> str:
    """Answer a small set of predefined questions; do not execute arbitrary code."""
    q = question.strip().lower()
    if not q:
        return "Enter a question first."

    overview = dataset_overview(df)

    if any(term in q for term in ("how many rows", "row count", "number of rows", "records")):
        return f"The dataset contains {overview['rows']:,} rows."
    if any(term in q for term in ("how many columns", "column count", "columns available", "column names")):
        return "Columns: " + ", ".join(overview["column_names"])
    if any(term in q for term in ("missing", "null", "incomplete")):
        missing = overview["missing_by_column"]
        if not missing:
            return "No missing values were found."
        return "Missing values by column:\n" + "\n".join(
            f"- {name}: {count:,}" for name, count in missing.items()
        )
    if "duplicate" in q:
        return f"The dataset contains {overview['duplicate_rows']:,} duplicate rows."
    if any(term in q for term in ("summary", "statistics", "describe")):
        numeric = df.select_dtypes(include="number")
        if numeric.empty:
            return "There are no numeric columns to summarize."
        return numeric.describe().round(2).to_string()

    return (
        "I can currently answer predefined questions about row counts, column names, "
        "missing values, duplicate rows, and numeric summary statistics. "
        "LLM-based question answering is not implemented in this starter version."
    )
